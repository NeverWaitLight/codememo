<!DOCTYPE html>
<html lang="en">
<head>
	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Skycom电话插件</title>
<link rel="stylesheet" href="bootstrap.min.css">
<!--
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
-->
<script language="javascript" type="text/javascript" src="indexjs34.js"></script>
<script language="javascript" type="text/javascript" src="jquery-3.4.1.min.js"></script>
<script language="javascript" type="text/javascript" src="howler.min.js"></script>
<style>
	.text{text-align:center;}
</style>

</head>

<body>



<div class="container">
    <div class="page-header">
        <h2 style="margin-top:20px;margin-left:20px; text-align:center; ">USB电话中间件在线体验</h2>		

	
		
		<!--
        <a href=http://local.zorrosoft.com/Files/PluginOK.pdf>产品介绍</a>
        <a href=http://local.zorrosoft.com/Files/PluginOK.zip>中间件安装包</a>
		
        <a href=http://local.zorrosoft.com/Files/WrlSDK.zip>二次开发包(SDK)</a>
		-->
		<p id="serialno">设备串号：</p>
		<p id="cnnstate">设备未连接(此提示只针对4G电话)</p>
		<p id="messagenum">接收到知信内容：</p>
     
      
    </div>
    <div class="row" style="margin-bottom:20px;">
	
        <div class="col-sm-6 col-md-5 col-lg-4">
		
		
            <div>
				<!--ws://192.168.2.112:823-->
                <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_url" placeholder="连接" value="ws://192.168.2.180:823" />
                <button style="width:172px;font-size:15px" type="button" id="btn_conn" class="btn btn-primary" onClick="onConnectClick()">连接</button>
				<span style="width:20px;">&nbsp;</span>
                <button style="width:172px;font-size:15px" type="button" id="btn_close" class="btn btn-danger" disabled="disabled" onClick="onWSClose()">断开</button>
				
				<span style="width:20px;display:none;">&nbsp;</span>
                <button style="display:none;" type="button" id="btn_clear" class="btn btn-danger" onClick="onCleanRecord()">清空通讯记录</button>
            </div>
            <br />
			
		  
		   <div>
		   
		    <div style="margin-bottom:20px;">
            
             <button type="button" id="btn_ReStartPlugins" class="btn btn-info btn-block btn-danger" onClick="onReStartPluginsClick()">重启插件</button>
				
				
          </div>
		  
		<div style="margin-bottom:20px;">
            
           <button type="button" id="btn_QueryPlugineStatus" class="btn btn-info btn-block" onClick="onQueryPlugineStatusClick()">查询话机与插件服务连接状态</button>
				
				
          </div>
				
                <table class="table table-striped table-bordered table-hover" width="360" border="1">
  <tr>
  <!--onRaidoVoiceClick() -->
    <td><span style="width:100px;font-size:15px">振铃开关: </span></td>
    <td><input id="rd_ring" type="radio" checked="true" value="1" onClick="onRaidoRingClick()"></td>
    <td><span style="width:100px;font-size:15px">PC喇叭开关: </span></td>
    <td><input  id="rd_voice" type="radio" value="0" onClick="onRaidoVoiceClick()"></td>
  </tr>
  <tr>
    <td><span style="width:10px;font-size:15px">自动接听开关: </span></td>
    <td><input id="rd_answer" type="radio" value="0" onClick="onRaidoAnswerClick()"></td>
    <td><span style="width:10px;font-size:15px">静音开关: </span></td>
    <td><input id="rd_mute" type="radio" value="0" onClick="onRaidoMuteClick()"></td>
  </tr>
    <tr>
    <td><span style="width:10px;font-size:15px">答录开关: </span></td>
    <td><input id="rd_dl" type="radio" value="0"  onClick="onRaidoDLClick()"></td>
    <td><span style="width:10px;font-size:15px">耳机摘机: </span></td>
    <td><input id="rd_he" type="radio" value="0" onClick="onRaidoheClick()"></td>
  </tr>
   <tr>
    <td><span style="width:10px;font-size:15px">拨号音开关: </span></td>
    <td><input id="rd_dvoice" type="radio" value="0"  onClick="onRaidoDVoiceClick()"></td>
	<td><span style="width:10px;">电话耳机开关: </span></td>
	<td><input id="rd_mobilehs" type="radio" value="0" onClick="onRaidomobilehsClick()" ></td>
	
  </tr>
  
   <tr>
    <td><span style="width:10px;font-size:15px">ICM通道开关: </span></td>
    <td><input id="rd_icm" type="radio" value="0"  onClick="onRaidoICMClick()"></td>
	 <td><span style="width:10px;font-size:15px">删除信息: </span></td>
    <td><input id="rd_delmsg" type="radio" value="0"  onClick="onRaidoDelMsgClick()"></td>
	
  </tr>
 
   <tr >
    <td><span style="width:10px;font-size:15px">录音上传本地局域网络: </span></td>
    <td><input id="rupload" type="radio" value="0"  onClick="onRaidoRUploadClick()"></td>
	 <td><span style="width:10px;font-size:15px">录音上传云存储网络: </span></td>
    <td><input id="rupremote" type="radio" value="0"  onClick="onRaidoRUpremoteClick()"></td>
	
  </tr>


</table>

				
			
				<span style="width:10px;display:none;">PC耳机开关: </span>
				<input style="display:none;" id="rd_pchs" type="radio" value="0" onClick="onRaidopchsClick()">
				
				<span style="width:10px;display:none;">电话耳机开关: </span>
				<input style="display:none;" id="rd_mobilehs" type="radio" value="0" onClick="onRaidomobilehsClick()" >
				
			
          </div>
			
			 <div>
		
				<span style="width:10px;display:none;">PC耳机开关: </span>
				<input style="display:none;" id="rd_pchs" type="radio" value="0" onClick="onRaidopchsClick()">
				
				<span style="width:10px;display:none;">电话耳机开关: </span>
				<input style="display:none;" id="rd_mobilehs1" type="radio" value="0" onClick="onRaidomobilehsClick()" >
				
			
            </div>
		
			 <div style="margin-bottom:20px;display:none;">
            
              <button style="display:none;" type="button" id="btn_init" class="btn btn-info btn-block" onClick="onDevInit()">设备初始化</button>
				
				
          </div>
            <div style="margin-bottom:20px;display:none;">
              <textarea name="textarea" class="form-control" id="inp_send" style="margin-bottom:3px;min-width:350px;min-height:10px;" placeholder="请输入发送的内容"></textarea>
              <button type="button" id="btn_send" class="btn btn-info btn-block" onClick="onSendComand()">发送(Ctrl+Enter)</button>
				
				
          </div>
            <div style="margin-bottom:20px;">
            
             <button type="button" id="btn_serial" class="btn btn-info btn-block" onClick="onDeleteUploadClick()">删除本地录音文件</button>
				
				
          </div>
          
		   <div style="margin-bottom:20px;">
             <input type="text" class="form-control" size="80" style="margin-bottom:3px;" id="inp_serial"  value="0001" />
             <button type="button" id="btn_serial" class="btn btn-info btn-block" onClick="onSetSN()">设置序列号</button>
				
				
          </div>
		  
		     <div style="margin-bottom:20px;">
			 <p style="font-size:15px" >设备录音文件的路径：</p>
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_recordaddr"  value="E:\record\sound.wav" />
             <button style="display:none;"  type="button" id="btn_recordaddr" class="btn btn-info btn-block" onClick="onSavePathClick()">设置录音路径		</button>
				
		  </div>
		    <div style="margin-bottom:20px; " >
			 <p style="font-size:15px" >设置网络上传帐号：</p>
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_uploaduser"  value="" />
            
		  </div>
		    <div style="margin-bottom:20px;">
			 <p style="font-size:15px" >设置网络上传密码：</p>
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_uploadpw"  value="" />
           
				
		  </div>
		    <div style="margin-bottom:20px; " >
			 <p style="font-size:15px" >设置录音文件保存的本地局域网络路径：</p>
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_recorduploadaddr"  value="\\192.168.2.114\test" />
             <button style="display:none;"  type="button" id="btn_recordaddr" class="btn btn-info btn-block" onClick="onSavePathClick()">设置录音路径		</button>
				
		  </div>
		   <div style="margin-bottom:20px;" >
			 <p style="font-size:15px" >设置录音文件保存的云存储路径：</p>
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_recordremoteaddr"  value="192.168.2.180:8888/upload" />
            
				
		  </div>
		 
		 
		   <div style="margin-bottom:20px;">
             <input type="text" style="font-size:15px"  class="form-control" size="80" style="margin-bottom:3px;" id="inp_flash"  value="300" />
             <button type="button" id="btn_flash" style="font-size:15px" class="btn btn-info btn-block" onClick="onSetFlashClick()">设置闪断时间</button>
				
				
          </div>
		  
		   <div style="margin-bottom:20px;">
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_out"  value="9" />
             <button type="button" id="btn_out"style="font-size:15px"  class="btn btn-info btn-block" onClick="onOutCodeClick()">设置出局码</button>
				
		   </div>
		   
		    <div style="margin-bottom:20px;">
             <input type="text" style="font-size:15px" class="form-control" size="80" style="margin-bottom:3px;" id="inp_pmsg"  value="天天开心" />
             <button type="button" id="btn_sendmsg"style="font-size:15px"  class="btn btn-info btn-block" onClick="onSendMsgClick()">发送信息</button>
				
		   </div>
		  
		 
		  
        </div>
		
		<div id="music" style="display:none;"  >
	    <div id="container">
		<h3 id="musicName">天天开心</h3>
		
		<audio  src="answertip.mp3" controls id="audio1"></audio>
		<div>
			<button id="play">play</button>
			<button id="pause">pause</button>
			<button id="prev">prev</button>
			<button id="next">next</button>
		</div>
	    </div>
        </div>

		
		  
        <div class="col-sm-6 col-md-7 col-lg-8">
            <div id="div_msgzone" class="panel panel-default">
                <div style="display:none;" class="panel-heading">通讯记录</div>
                
				
			
			</br>
			</br>
			
			<div id="div_icm" style="height:350px;display:none;" class="text">
				</br>
				</br>
               <h1 id="phone_icm"></h1>
			   </br>
			   <h3 id="tip_a">正在答录.....</h3>
			   </br>
			   
			   <input style="width:200px;font-size:15px" id="btn_acp" type="button" class="btn btn-info" value="接听" onClick="onAcpClick()">
			   <input style="width:200px;font-size:15px" id="btn_acp" type="button" class="btn btn-info" value="拒接" onClick="onRefuseClick()">
				
				
			
            </div>
			
			 <div id="div_dlg" style="margin-bottom:20px;height:320px;">
             <input type="text" class="form-control" size="80" style="margin-bottom:3px;" id="inp_phonecode"  value="" onKeyPress="javascript:xKeyEvent(event);"  onKeyDown="onInp_phonecodeKeyDown();"/>
			 <table class="table table-striped table-bordered table-hover" table-layout=fixed; width=100%; align="center" border="1">
  <tr>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_1" type="button" value="1" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_2" type="button" value="2" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_3" type="button" value="3" onClick="onNumClick(this)"></td>
     <td rowspan="2"><input class="btn btn-default" style="width:100%; height:100px;font-size:15px" id="record" type="button" onClick="onRecordClick()"value="录音"></td>
  </tr>
  <tr>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_4" type="button" value="4" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_5" type="button" value="5" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_6" type="button" value="6" onClick="onNumClick(this)"></td>
    </tr>
  <tr>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_7" type="button" value="7" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_8" type="button" value="8" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_9" type="button" value="9" onClick="onNumClick(this)"></td>
	<!--
    <td rowspan="2"><input class="btn btn-default" style="width:100%; height:100px;font-size:15px" id="flash" type="button" onClick="onFlashClick()" value="闪断"></td>
	-->
	 <td><input class="btn btn-default" style="width:100%; height:100%;font-size:15px" id="flash" type="button" onClick="onFlashClick()" value="闪断"></td>
  </tr>
  <tr>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_x" type="button" value="*" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_0" type="button" value="0" onClick="onNumClick(this)"></td>
    <td><input class="btn btn-default" style="width:100%;height:100%;font-size:15px" id="num_j" type="button" value="#" onClick="onNumClick(this)"></td>
	 <td><input class="btn btn-default" style="width:100%; height:100%;font-size:15px" id="inp_relay" type="button" onClick="onRelayClick()" value="转播"></td>
    </tr>
</table>

			   <div id="div_icm" style="height:100px;" class="text">
				<table class="table table-striped table-bordered table-hover" table-layout=fixed; width=100%; align="center" border="1">
  <tr>
    <td> <button type="button" id="btn_dial" style="font-size:15px" class="btn btn-info btn-block" onClick="onDialClick()">摘机</button></td>
    <td> <button type="button" id="btn_hold" style="font-size:15px" class="btn btn-info btn-block" onClick="onHoldClick()">保留</button></td>
   
  </tr>
  <tr style="display:none;">
   
    <td> <button type="button" id="btn_unhold" style="font-size:15px" class="btn btn-info btn-block" onClick="onUnHoldClick()">不保留</button></td>
    <td> <button type="button" id="btn_hangup" style="font-size:15px" class="btn btn-info btn-block" onClick="onHangupClick()">挂机</button></td>
  </tr>
  
   
</table>

				
				
			
            </div> 
			</div>
			</div>
			 <div id="div_msgframe" style="margin-top:40px;" class="panel panel-default">
				<p style="font-size:15px" >客户端与服务端数据交互显示:</p>
             <div id="div_msg" class="panel-body" style="min-height:300px;"></div>
			
			</div>	
			
			</div>
		
			
			
    </div>

</div>
<script>

init();
/*var user = document.getElementById("inp_uploaduser").value;
		var pw  = document.getElementById("inp_uploadpw").value;
		var netaddr = document.getElementById("inp_recorduploadaddr").value;
		recordpath = '{"path":"'+netaddr+'","user":"'+user+'","pawd":"'+pw+'"}';
		window.alert(recordpath);
*/

 //onConnectClick();
 
 /*
				var	  mAudio = document.getElementById("audio1");
					  mAudio.addEventListener('ended',function(){
					  
		               mAudio.src = "test.mp3";
					   mAudio.play();
						
					  
					},false);
			
				//mAudio.currentTime = 0;//重新播放
	            mAudio.play();
				
 */

</script>

</body>
</html>





























