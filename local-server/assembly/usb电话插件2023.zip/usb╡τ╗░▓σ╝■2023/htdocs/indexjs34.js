
	var wsClient = null; //ws客户端对象
	var recordText = "CCCCC";
	var apush = [];
	
	var ringCount = 0;
	
	var cpush = [];
	var spush = [];
	
	var wsip = null;
	var connectTimeOut = null;
	
	var dlyDlokTimeout = null;
	
	var inp_url = null;
	var showMsg = null;
	var btn_close = null;
	var btn_conn = null;
	var btn_send = null;
	var div_msg = null;
	var inp_send = null;
	
	var phoneCode = "";
	var phoneCodeShow = "";

	var p_status = 0;//摘挂机状态0:为挂机;1：为摘机;2:为HOLD;3：为耳机摘机
	var r_status = 0;//录音机状态： 0：停止录音 1:正在录音
	var a_status = 0;//答录的状态： 0：停止答录 1：准备答录 2:正在答录
	var dv_status = 0;//播号音开关: 0: 播号音关闭 1：播号音打开
	
	var icm_flag = 0;//ICM通道关：0；ICM通道开： 1
	
	var has_dial = false;//标识是否已发送预拨号命令
	
//	window.alert("顺其自然，天天开心。");
    //记录上一次发送的指令
	var pre_command ="";
	//是否发送了停止录音命令的标识
	var HasSendStopR = false;
	var Enable_17 = true;
	
	var holdTo503 = false;
	
	
	function init(){
		
		showMsg = document.getElementById("div_msg");
		inp_url = document.getElementById("inp_url");
		btn_close = document.getElementById("btn_close");
		btn_close.disabled = true;
		btn_conn = document.getElementById("btn_conn");
		btn_send = document.getElementById("btn_send");
		btn_send.disabled = true;
		div_msg = document.getElementById("div_msg");
		inp_send = document.getElementById("inp_send");
		
		
		window.addEventListener("beforeunload", function(event) {
													 
            event.returnValue = "我在这写点东西...";
			
		  	
		});
	}
	
	
var pre_amsg ="";

function strPush(str){
		var mydate = new Date();
		var currentime = mydate.toLocaleString( ); 
		apush.push(currentime);
		apush.push(":");
		apush.push(str);
		apush.push("<br />");
		apush.push(pre_amsg);
		recordText = apush.join("");
		pre_amsg = recordText;
		
		showMsg.innerHTML = recordText;
		apush = [];
}
//type:0:发出去的信息；1：接收的信息
function strPushByType(type,str){
	
	
	var mydate = new Date();
		var currentime = mydate.toLocaleString( ); 
		switch(type){
			case 0:
				apush.push("客户端发出的信息-->");
				pre_command = str;
			break;
			case 1:
				apush.push("服务端发来的信息-->");
			break;
			case 2:
				apush.push("重发客户端信息-->");
			break;
		}
		apush.push(currentime);
		apush.push(":");
		apush.push(str);
		apush.push("<br />");
		apush.push(pre_amsg);
		recordText = apush.join("");
		pre_amsg = recordText;
		
		showMsg.innerHTML = recordText;
		apush = [];
	
}
	
	
function oNreceid(){
		   
	  //这句非常重要，如果没有这句话，则无法正常通讯
	 //  wsClient.send('Hello Server');
      //接收WS服务器返回的消息
       wsClient.onmessage = function(e){
	   		
	   		ExplainCommane(e.data);
				
       }
		
		wsClient.onclose = function(e){
			judgeConnect();
		}
 
}
	
	function showmsgConnecttimeout(){
	
	   
	
		if(wsClient.readyState === WebSocket.CONNECTING){
		 
			
		}else if(wsClient.readyState === WebSocket.CLOSING){
			
			
		}else if(wsClient.readyState === WebSocket.OPEN){
		
			checkPstatus();
			
		}else if(wsClient.readyState === WebSocket.CLOSED){
		    strPushByType(1,"断开连接");
			//reInit();
		}else{
			 strPushByType(1,"断开连接");
			//reInit();
		}
	}
	
	function judgeConnect(){
	
		
		if(wsClient.readyState === WebSocket.CONNECTING){
			strPushByType(1,"正在连接");
		}else if(wsClient.readyState === WebSocket.CLOSING){
			strPushByType(1,"正在断开连接");
		}else if(wsClient.readyState === WebSocket.OPEN){
			strPushByType(1,"已连接上："+wsip+" 可以通讯了");
			btn_close.disabled = false;
			btn_conn.disabled = true;
			btn_send.disabled = false;
			//连接上时，应先初始化设备。
			onDevInit();
			
		}else if(wsClient.readyState === WebSocket.CLOSED){
		    
			strPushByType(1,"连接关闭");
			btn_close.disabled = true;
			btn_conn.disabled = false;
			btn_send.disabled = true;
			reInit();
		}
	}
	//连接USB中间件
	function onConnectClick(){
	
		wsip = inp_url.value;
		if(wsip == null || wsip == ""){
			strPushByType(0,"服务器地址不能为空.");
			return;
		}
		
		strPushByType(0,"开始连接.");
		
		
		
        wsClient = new WebSocket(wsip);
		
		wsClient.onopen = function(){
      
	   	connectTimeOut = 0;
		judgeConnect();
		
		oNreceid();
		
		
	 }
	  
	 setTimeout("showmsgConnecttimeout()","3000"); 
	 
	  
	  
	}
	
	
	function onWSClose(){
	
	 	
		wsClient.close(); 
		
		judgeConnect();
		
	 	
	}
	
	function onCleanRecord(){
	   
    	recordText = "";
		apush = null;
		apush = [];
		pre_apush = "";
		div_msg.innerHTML = recordText;
	
	}
	
	
	
	function onSendComand(){
	     //textarea用JS填写内容时，应用innerText这个属性，得到这个属性的值侧用value这个值
		//document.getElementById("inp_send").innerText = "天天开心！";
		var context = inp_send.value;
		
		wsClient.send(context);
	}
	
	//用于构造命令
	function commandNormal(first,second,third){
	
		var jsonp = {};
		if(third != null){
			jsonp = thirdNormalParameter(third);
		}
		var jsonpStr = JSON.stringify(jsonp);
		
		var jsonCommand = {"req":"HP_Init","rid":1,"para":{"Para":"0"}};
		jsonCommand.req = first;
		jsonCommand.rid = second;
		jsonCommand.para = jsonp;
		
		var jsonStr = JSON.stringify(jsonCommand);
		
	
		return jsonStr;
		
	}
	
	function commandSpecial(first,second,thirdp1,thirdp2){
		
		
		var jsonp =  thirdSpecialParameter(thirdp1,thirdp2);
		var jsonCommand = {"req":"HP_Init","rid":1,"para":{"Para":"0"}};
		jsonCommand.req = first;
		jsonCommand.rid = second;
		jsonCommand.para = jsonp;
		
		var jsonStr = JSON.stringify(jsonCommand);
		
		return jsonStr;
		
	}
	
	function commandStopRecorder(user,pawd,netaddr){
		
		var jsonCommand = {"req":"HP_StopRecordFile","rid":17, "para":{"path":"\\192.168.2.100\\record\\","user":"guest","pawd":"guest"}} ;
		
		
		var jsonZL = {"path":"\\192.168.2.100\\record\\","user":"guest","pawd":"guest"};
		jsonZL.path = netaddr;
		jsonZL.user = user;
		jsonZL.pawd = pawd;
		
		
		
		jsonCommand.req = "HP_StopRecordFile";
		jsonCommand.rid = 17;
		jsonCommand.para = jsonZL;
		
		var jsonStr = JSON.stringify(jsonCommand);
		strPushByType(0,jsonStr);
		
		return jsonStr;
		
	}


	
	
	function commandUpRemote(remoteaddr){
		//{"req":"HP_UpLoadFile","rid":30, "para":{"remote":"101.233.131.168/upload","localfile":"D:\\record\\sound.wav"}}
		
		var jsonCommand = {"req":"HP_UpLoadFile","rid":30, "para":{"remote":"http://101.233.131.168/test/upload/111","localfile":"D:\\record\\sound.wav"}} ;
		var localaddr=document.getElementById("inp_recordaddr").value;;
		
		var jsonZL = {"remote":"http://101.233.131.168/test/upload/111","localfile":"D:\\record\\sound.wav"};
		jsonZL.remote = remoteaddr;
		jsonZL.localfile=localaddr;
		
		
		
		jsonCommand.req = "HP_UpLoadFile";
		jsonCommand.rid = 30;
		jsonCommand.para = jsonZL;
		
		var jsonStr = JSON.stringify(jsonCommand);
		strPushByType(0,jsonStr);
		
		return jsonStr;
		
	}
	
	function sendUpRemote(remoteaddr){
		
		var strcommand = commandUpRemote(remoteaddr);
		wsClient.send(strcommand);
	
	}
	
	
	function sendStopRecorder(user,pawd,netaddr){
		
		var strcommand = commandStopRecorder(user,pawd,netaddr);
		
		//var jsonStr = JSON.stringify(strcommand);
        //strPushByType(0,jsonStr);
		
		wsClient.send(strcommand);
	
	}
	
	
	function sendHangUpStopRecorder(user,pawd,netaddr){
		
		var strcommand = commandHangUpStopRecorder(user,pawd,netaddr);
		wsClient.send(strcommand);
	
	}
	function thirdNormalParameter(param){
		var jsonParam = {"Para":param};
		
		return jsonParam;
	}
	
	function thirdSpecialParameter(param1,param2){
		var jsonParam = {"Para":param1,"Num":param2};
		return jsonParam;
	}
	
	
	function sentPCommand_R(first,second,third,forth){
	var strcommand = commandSpecial_R(first,second,third,forth);
	strPushByType(0,strcommand);
	wsClient.send(strcommand);
}
	
	function commandSpecial_R(first,second,thirdp1,thirdp2){
		
		var jsonp =  thirdSpecialParameter_R(thirdp1,thirdp2);
		var jsonCommand = {"req":"HP_Init","rid":1,"para":{"Para":"0"}};
		jsonCommand.req = first;
		jsonCommand.rid = second;
		jsonCommand.para = jsonp;
		
		var jsonStr = JSON.stringify(jsonCommand);
		
		return jsonStr;
		
	}
	
	
	function thirdSpecialParameter_R(param1,param2){
	    var jsonParam = {"type":param1,"Para":param2};
		
		var jsonStr = JSON.stringify(jsonParam);
		
		return jsonParam;
	}
	
	function commandSpecial_M(first,second,thirdp1,thirdp2){
		
		var jsonp =  thirdSpecialParameter_M(thirdp1,thirdp2);
		var jsonCommand = {"req":"HP_Init","rid":1,"para":{"Para":"0"}};
		jsonCommand.req = first;
		jsonCommand.rid = second;
		jsonCommand.para = jsonp;
		
		var jsonStr = JSON.stringify(jsonCommand);
		
		return jsonStr;
		
	}
	
	function thirdSpecialParameter_M(param1,param2){
	    var jsonParam = {"Para":param1,"Num":param2,};
		
		var jsonStr = JSON.stringify(jsonParam);
		
		return jsonParam;
	}
	
	function sentPCommand_M(first,second,third,forth){
	var strcommand = commandSpecial_M(first,second,third,forth);
	strPushByType(0,strcommand);
	wsClient.send(strcommand);
}
	
	
	
	
	function ExplainCommane(command){
	
	
	var jsonString = JSON.parse(command);
	
    
	
	var event = jsonString.event;
	var ret = jsonString.ret;
	
	
	if(event == null && ret == null){
		
	    return "err";
	}else{
		
		strPushByType(1,command);
		
	}
	
	
	if(event != null){
		//strPush(command);
		//document.getElementById("div_msg").innerHTML = recordText;
		//return;
	
	
	var type = jsonString.type;
	var wParam = jsonString.data.wParam;
	
	var lParam = jsonString.data.lParam;
	
	//判断lParam的确类型
	

	switch(type){
		case "501":
		case "511":
		if(type == "501"){
			icm_flag = 0;
		}else{
			icm_flag = 1;
		}
	
		var cnnstate = document.getElementById("cnnstate");
		cnnstate.innerHTML = "设备已连接";
		
		
		
		break;
		
		case "512":
			var cnnstate = document.getElementById("cnnstate");
			icm_flag = 1;
			if(lParam == 1){
				cnnstate.innerHTML = "设备已连接(联机成功)";
			}else{
				cnnstate.innerHTML = "设备已连接(联机不成功)";
			}
		break;
		
		
		case "502":
		
			
			
			if(lParam == "0L"){
				
				var cnnstate = document.getElementById("cnnstate");
				cnnstate.innerHTML = "设备已全部断开";
				
				
			}else{
				
				
				
				var cnnstate = document.getElementById("cnnstate");
				cnnstate.innerHTML = "已断开设备";
				
				
			}
			document.getElementById("div_msg").innerHTML = recordText;
			
			onWSClose();
		break;
		case "515":
			if(lParam == 1){
				window.alert("对方已摘机");
			}else{
				window.alert("对方已经挂机");
			}
			break;
		case "516":
			if(lParam == 1){
				window.alert("耳机插入");
			}else{
				window.alert("耳机拨出");
			}
		
		break;
		case "517":
		
		var cnnstate = document.getElementById("messagenum");
		cnnstate.innerHTML = "知信内容："+lParam;
		break;
		case "518":
		window.alert(lParam);
		break;
		
		case "514":
		
			if(lParam == 1){
				if(ringCount > 0){
					if(a_status == 1){
					
						ringCount == 0;
					//{"req":"HP_ playOGM","rid":29,"para":{"Para":"1"}} 
					    SetLeaveRecordFlag = 1; 
						sentNCommand("HP_SetLeaveRecord",10,"1");
						showincomDlg();
					
						return;
					
					}
				
				}
			
				clearTimeoutF();
				setP_status(1);
				ringCount = 0;
			//document.getElementById("div_msg").innerHTML = recordText;
		//	p_status = 1;
		
		   		 a_status = 0;
			//btn_dial = document.getElementById("btn_dial");
			//btn_dial.className = "btn btn-danger btn-block";
			//btn_dial.innerHTML = "挂机";
				clearTimeoutF();
			 	clearTimeoutA();
				showDialDlg();
		
	        	inp_phonecode = document.getElementById("inp_phonecode");
	        	inp_phonecode.value = phoneCodeShow;
			
				if(r_status == 1){
			        
					stopRecorder();
				}
				
				
				showUIDialStatus(p_status);
			}else{
				clearTimeoutF();
				
				if(lParam == 0){
					
					if(r_status == 1){
						stopRecorder();
					}
					
					ringCount = 0;
			    	setP_status(0);
					a_status = 0;
					clearTimeoutA();
			
					pushPCS();
			
					
					phoneCode = "";
					phoneCodeShow = "";
					
					if(r_status == 1){
			
					
					}
			
            	}
			
			showDialDlg();
			
	        inp_phonecode = document.getElementById("inp_phonecode");
	        inp_phonecode.value = phoneCodeShow;
			showUIDialStatus(p_status);
		
			}
		break;
		
		case "503":
			
			//判断是否来铃
			if(ringCount > 0){
				if(a_status == 1){
					
					ringCount == 0;
					//{"req":"HP_ playOGM","rid":29,"para":{"Para":"1"}} 
					SetLeaveRecordFlag = 1;
					sentNCommand("HP_SetLeaveRecord",10,"1");
					showincomDlg();
					
					return;
					
				}
				
			}
			
			clearTimeoutF();
			setP_status(1);
			ringCount = 0;
		
		
		    a_status = 0;
		
			clearTimeoutF();
			clearTimeoutA();
			showDialDlg();
		
	        inp_phonecode = document.getElementById("inp_phonecode");
	        inp_phonecode.value = phoneCodeShow;
			if(r_status == 1 && !holdTo503){
			    holdTo503 = false;
				stopRecorder();
			}
		//	setTimeout("playAnswerTip()",5000);
		   
			
			showUIDialStatus(p_status);
		break;
		case "504":
		clearTimeoutF();
		if(lParam == "0"){
				
				ringCount = 0;
			    setP_status(0);
				a_status = 0;
				clearTimeoutA();
				isDialOnline = false;
			
				pushPCS();
			
				if(r_status == 1){
					
					stopRecorder();
				}
				
				phoneCode = "";
				phoneCodeShow = "";
				
				
	           

				
            }else if(lparam = "1"){
			
				ringCount = 0;
			    setP_status(2);
		
				PreDialing = false;
				
			
			}
			
			showDialDlg();
			
	        inp_phonecode = document.getElementById("inp_phonecode");
	        inp_phonecode.value = phoneCodeShow;
			showUIDialStatus(p_status);
			holdTo503 = false;
			
		
		
		break;
		case "505":
			
			showincomDlg();
			phone_icm = document.getElementById("phone_icm");
			
			phone_icm.innerHTML = lParam;
			phoneCode = lParam;
			phoneCodeShow = lParam;
			clearTimeoutF();
			
		break;
		case "506":{
		
		    
			
			if(icm_flag == 1){
			
				lParam = 0;
				ringCount = 2;
				
				//window.alert("506");
			}else{
				
				if(a_status == 1){
					return;
				}
			}
		    
			if(lParam == 1){
				
			}else{
				
				
				
				
				ringCount++;
			
				if(ringCount >= 2){
					showincomDlg();
					clearTimeoutF();
					incomTimeout = setTimeout("incomTimeoutF()",5000);
					
					if(ringCount == 3){
						var isLaw = judgeNetLaw();
						if(isLaw == false){
							return;
						}
						rd_dl = document.getElementById("rd_dl");
						var value = rd_dl.value;
						if(value == "1"){
							clearTimeoutF();
							a_status = 1;
							audioend = 0;
							//{"req":"HP_OffHookCtrl","rid":3,"para":{}}
							//马上来铃就进行摘机操作会摘不起机。
							dlyDlokTimeout = setTimeout("dloffHookDelay()",1000);
							
							
							
						}
					}
				}else{
					if(icm_flag == 1){
						//window.alert("快乐幸福！")
						ringCount = 0;
						setP_status(0);
						a_status = 0;
						clearTimeoutA();
			//	btn_dial = document.getElementById("btn_dial");
			//	btn_dial.className = "btn btn-info btn-block";
			//	btn_dial.innerHTML = "摘机";
						pushPCS();
				//if(r_status == 1 ){
						if(r_status == 1){
				
							stopRecorder();
						}
						
						phoneCode = "";
						phoneCodeShow = "";
						showDialDlg();
			
					}
				}
			}
		}
			
		break;
		case "507":
			
				if(has_dial == true){
						pushPCS();
						has_dial = false;
				}
				var temp = deASCII(lParam);
				
				if(isDialOnline  == false){
					addInp_phonecode(temp);
				}
				
	
			
		break;
		case "508":
			
			document.getElementById("div_msg").innerHTML = recordText;
		break;
		case "509":
	
			
			var rd_mute = document.getElementById("rd_mute");
		    if(lParam == 1){
				
				rd_mute.checked = true;
			}else{
				
				rd_mute.checked = false;
			}
		
		break;
		case "510":
			
			if(lParam == 0){
			
			//	btn_dial = document.getElementById("btn_dial");
			//	btn_dial.className = "btn btn-danger btn-block";
			//	btn_dial.innerHTML = "挂机";
				
				btn_dial = document.getElementById("btn_hold");
				btn_dial.className = "btn btn-info btn-block";				btn_dial.innerHTML = "保留";
				holdTo503 = false;
				setP_status(1);
            }else{
				
			   // h_status = 1;
				//btn_dial = document.getElementById("btn_dial");
				//btn_dial.className = "btn btn-primary btn-block";
				//btn_dial.innerHTML = "保留";
				btn_hold = document.getElementById("btn_hold");
				btn_hold.className = "btn btn-danger btn-block";
				btn_hold.innerHTML = "解除保留";
				holdTo503 = true;
				setP_status(3);
			}
		
		break;
		/*提示服务器接收数据异常。此时客户端应再次发送上一条命令*/
		case "519":
			rsendCommand();
		break;
		
		
	}
	}else{
		
		var err = jsonString.err;
		var ret = jsonString.ret;
		var rid = jsonString.rid;
		var data =jsonString.data;
		
		
		var AnswerData =  data.Ret;
		
		
	
		switch(rid){
			case 1:
			
			var err = jsonString.err;
			if(err != null)
			{
				 var hserial = "设备初始化错误:"+err;
				 document.getElementById("serialno").innerHTML = hserial;
				return;
			}
			  var no = data.SerialNo;
			
			  var hserial = "设备串号:"+no;
			  serialno = document.getElementById("serialno").innerHTML = hserial;
			 // onRaidoheClick();
			break;
			case 2:
				if(AnswerData == "0"){
					
				}
			break;
			case 3:
			if(AnswerData == "0"){
					
					
					if(ringCount > 0){
						if(a_status == 1){
						
							return;
					
				        }
				
					}
					
					
					inp_phonecode = document.getElementById("inp_phonecode");
					inp_phonecode.value = phoneCodeShow;
					showDialDlg();
					
					clearTimeoutA();
					setP_status(1);
			        showUIDialStatus(p_status);
				}
			break;
			case 4:
			case 26:
				if(AnswerData == "0"){
					setP_status(0);
					a_status = 0;
					
					if(r_status == 1){
					
						stopRecorder();
					}
					
					pushPCS();
					showDialDlg();
					phoneCode = "";
					phoneCodeShow = "";
					
	                inp_phonecode = document.getElementById("inp_phonecode");
	                inp_phonecode.value = phoneCodeShow;
					clearTimeoutA();
					setP_status(0);
			        showUIDialStatus(p_status);
				}
			break;
			case 25:
			case 5:
				if(AnswerData == "0"){
					
				
					a_status = 0;
					if(has_dial == true){
						pushPCS();
						has_dial = false;
					}
					clearTimeoutA();
					
				}
			break;
			case 6:
			
				var rd_ring = document.getElementById("rd_ring");
				if(AnswerData == "0"){

					
					var sopen = rd_ring.value;
				
					if(sopen == "1"){
						
						rd_ring.checked = false;
						rd_ring.value = "0";
						
					}else{
						
						rd_ring.checked = true;
						rd_ring.value = "1";
						
					}
				}
			break;
			case 7:
			
				//spush.pop();
			break;
			case 8:
			
			
			     switch(AnswerData)
				 {
					 case "0":
					    phoneCode = "";
					    phoneCodeShow = "";
					 	setP_status(0);
				 	 	
					 break;
					 case "1":
					 	setP_status(1);
					 	
					 break;
					 case "2"://耳机摘机
					 setP_status(3);
					 break;
					 case "3":
					 setP_status(1);
					 break;
				 }
				 
				
				 
				 showUIDialStatus(p_status);
			break;
			case 9:{
			
				var rd_voice = document.getElementById("rd_voice");
			
				
				if(AnswerData == "0"){
					
					var sopen = rd_voice.value;
					
					if(sopen == "1"){
						
						rd_voice.checked = false;
						rd_voice.value = "0";
						
					}else{
						
						rd_voice.checked = true;
						rd_voice.value = "1";
						
					}
				}
				
				
				
				}
			break;
			
			case 11:
				if(AnswerData == "0"){
					phoneCode = "";
					phoneCodeShow = "";
					inp_phonecode = document.getElementById("inp_phonecode");
					inp_phonecode.value = "";
				}
			break;
			case 12:
				var rd_dvoice = document.getElementById("rd_dvoice");
				if(AnswerData == "0"){
				
					var sopen = rd_dvoice.value;
					
					if(sopen == "1"){
						
						rd_dvoice.checked = false;
						rd_dvoice.value = "0";
						
					}else{
						
						rd_dvoice.checked = true;
						rd_dvoice.value = "1";
						
					}
				}else{
					var sopen = rd_dvoice.value;
					
					if(sopen == "0"){
						
						rd_dvoice.checked = false;
						
						
					}else{
						
						rd_dvoice.checked = true;
					
						
					}
					
				}
			break;
			case 13:
				var rd_answer = document.getElementById("rd_answer");
				if(AnswerData == "0"){
				
					var sopen = rd_answer.value;
					
					if(sopen == "1"){
						
						rd_answer.checked = false;
						rd_answer.value = "0";
						
					}else{
						
						rd_answer.checked = true;
						rd_answer.value = "1";
						
					}
				}else{
					var sopen = rd_answer.value;
					
					if(sopen == "0"){
						
						rd_answer.checked = false;
						
						
					}else{
						
						rd_answer.checked = true;
					
						
					}
					
				}
			break;
			case 14:
				if(AnswerData == "0"){
					window.alert("Flash时间设置成功!");
				}
			break;
			case 15:
				if(AnswerData == "0"){
					window.alert("出局码设置成功!");
				}
			break;
			case 16:
				if(AnswerData == "0"){
					
					r_status = 1;
					if(a_status == 2){
						
						a_status = 3;
						setTimeout("answer_end()",30000);
					}else{
						r_status = 1;
						btn_record = document.getElementById("record");
						btn_record.className = "btn btn-success btn-block";
					}
					
				}else{
					window.alert("录音不成功！");
					
				}
			break;
			case 17:
			   /*  if(Enable_17 == false){
					 return;
				 }
				 Enable_17 = false;	 
			     setTimeout("Enable17Event()","1500");
				*/
				if(AnswerData == "0"){
				    
					var temp_a = a_status;
					var temp_r = r_status;
					r_status = 0;
					a_status = 0;
					btn_record = document.getElementById("record");
					btn_record.className = "btn btn-default";
					NotSendStopREvent();
					
					//if(temp_r == 1 && temp_a > 0){
						//sentNCommand("HP_HangUpCtrl",4,null);
					//}
				}else if(AnswerData == "1"){
					window.alert("停止录音失败！");
				}else if(AnswerData == "2"){
					window.alert("访问网络路径失败！");
				}else if(AnswerData == "3"){
					window.alert("复制文件到网络路径失败！");
				}
			break;
			case 30:
				if(AnswerData == "0"){
					
				}else if(AnswerData == "1"){
					window.alert("录音文件上传云端失败！");
				}
			break;
			case 18:
				if(AnswerData == "0"){
					phoneCode = "";
					phoneCodeShow = "";
					inp_phonecode = document.getElementById("inp_phonecode");
					inp_phonecode.value = "";
				}
			break;
			case 19:
			    
				if(p_status == 1 || p_status == 3){
                    
					setP_status(2);
					showUIDialStatus(p_status);
					holdTo503 = true;
				}else{
					setP_status(pre_p_status);
					showUIDialStatus(p_status);
				}
			break;
			case 20:
				var rd_mute = document.getElementById("rd_mute");
				if(AnswerData == "0"){
					
					var sopen = rd_mute.value;
					
					if(sopen == "1"){
						
						rd_mute.checked = false;
						rd_mute.value = "0";
						
					}else{
						
						rd_mute.checked = true;
						rd_mute.value = "1";
						
					}
				}
			break;
			case 21:
				var rd_pchs = document.getElementById("rd_voice");
				if(AnswerData == "0"){
					
					var sopen = rd_pchs.value;
					
					if(sopen == "1"){
						
						rd_pchs.checked = false;
						rd_pchs.value = "0";
						
					}else{
						
						rd_pchs.checked = true;
						rd_pchs.value = "1";
						
					}
				}
			break;
			case 22:
				var rd_mobilehs = document.getElementById("rd_mobilehs");
				if(AnswerData == "0"){
					
					var sopen = rd_mobilehs.value;
					
					if(sopen == "1"){
						
						rd_mobilehs.checked = false;
						rd_mobilehs.value = "0";
						
					}else{
						
						rd_mobilehs.checked = true;
						rd_mobilehs.value = "1";
						
					}
				}else{
					var sopen = rd_mobilehs.value;
					
					if(sopen == "1"){
						
						rd_mobilehs.checked = true;
						
						
					}else{
						
						rd_mobilehs.checked = false;
						
						
					}
					
				}
			break;
			case 23:
				var rd_icm = document.getElementById("rd_icm");
				if(AnswerData == "0"){
					
					var sopen = rd_icm.value;
					
					if(sopen == "1"){
						
						rd_icm.checked = false;
						rd_icm.value = "0";
				        //icm_flag = 0;
						
					}else{
						
						rd_icm.checked = true;
						rd_icm.value = "1";
						//icm_flag = 1;
						
					}
				}else{
					var sopen = rd_icm.value;
					
					if(sopen == "1"){
						
						rd_icm.checked = true;
						
						
					}else{
						
						rd_icm.checked = false;
						
						
					}
					
				}
			break;
			case 24:
			    
			break;
			case 25:
			break;
			case 26:
			break;
			case 27:
				var rd_delmsg = document.getElementById("rd_delmsg");
				rd_icm.checked = false;
				if(AnswerData == "0"){
					window.alert("信息删除成功");
					
				}else{
					window.alert("信息删除不成功");
				}
			break;
			case 28:
			      if(p_status != 3 ){
					 p_status = 3;
					 rd_he = document.getElementById("rd_he");
					 rd_he.value = "1";
					 rd_he.checked = true;
				 }
			break;
			case 10:
		
								
			  if(SetLeaveRecordFlag == 1){
				if(a_status == 1){
					a_status = 2;
					  mAudio = document.getElementById("audio1");
					  mAudio.addEventListener('ended',function(){
					  
		                
						if(audioend == 0){
								
						 
						 	audioend = 1;
					 	 	
					  	 	var path = document.getElementById("inp_recordaddr").value;
				
					  	 	//sentNCommand("HP_ playOGM",29,"0");
				
					  		if(path == null || path ==""){
						
						    	return;
					  	 	}
					  		sentPCommand_R("HP_StartRecordFile",16,2,path);
						}
					  
					},false);
			
				playAnswerTip();
				}
			  }
			  
			break;
			
			
			case 35:{
				var cnnstate = document.getElementById("cnnstate");
				if(AnswerData == "0"){
				
		       	 	cnnstate.innerHTML = "设备已连接";
					window.alert("话机连接正常!");
				}else if(AnswerData == "1"){
					cnnstate.innerHTML = "设备未连接(此提示只针对4G电话)";
					window.alert("话机未连接!");
				}	
			}
			break;
		}
		
		
	}
	
	return null;
	
	
}

var audioend = 0;

function audioEnded() {
    
    }


function onDevInit(){
	
	sentNCommand("HP_Init",1,"0");
}
	
	
function onSetSN(){
	
	var serialNo = document.getElementById("inp_serial").value;
	
	if(serialNo == null )
		return;
	
	sentNCommand("HP_SetSerialNo",2,serialNo);
	
}

function onOutCodeClick(){
	if(p_status != 0)
		return;
	
	var outcode = document.getElementById("inp_out").value;
	if(outcode == null)
		return;
	var strleng = outcode.length;
	
	if(strleng > 3)
	return;
	
	
	sentNCommand("HP_SetOutcode",15,outcode);
}

function onSetFlashClick(){
	

	inp_flash = document.getElementById("inp_flash");
	var flashtime = inp_flash.value;
	
	
	if(flashtime == null)
		return;
		//0--100ms,1--180ms,2--300ms,3--600ms,4--1000ms之间
		var numf = 3;
	switch(flashtime){
		case  "100":
			numf = "0";
		break;
		case  "180":
			numf = "1";
		break;
		case "300":
			numf = "2";
		break;
		case "600":
			numf = "3";
		break;
		case "1000":
			numf = "4";
		break;
	}

    sentNCommand("HP_SetFlashTime",14,numf);
 
}

function onSavePathClick(){
	
	
	var savepath = document.getElementById("inp_recordaddr").value;
	if(savepath == null)
		return;
	

	
	
	
	var strcommand = commandNormal("HP_StartRecordFile",16,savepath);
	
	wsClient.send(strcommand);
}

function sentNCommand(first,second,third){
	var strcommand = commandNormal(first,second,third);
	strPushByType(0,strcommand);
	
	wsClient.send(strcommand);
	
}

function rsendCommand(){
	strPushByType(2,pre_command);
	wsClient.send(pre_command);
}

function onRaidoRingClick(){
	
	var rd_ring = document.getElementById("rd_ring");
	var sopen = rd_ring.value;
	
	if(sopen == "1"){
		
		sentNCommand("HP_Bell",6,"0");
	}else{
		
		sentNCommand("HP_Bell",6,"1");
	}
}
//{"req":"HP_SetLocalRecord","rid":9,"para":{"Para":"1"}} 
function onRaidoVoiceClick(){
	
	if(p_status != 0)
		return;
	
	var rd_voice = document.getElementById("rd_voice");
	var sopen = rd_voice.value;
	
	if(sopen == "1"){
		
		sentNCommand("HP_SetPCEarSpk",21,"0");
	}else{
		
		sentNCommand("HP_SetPCEarSpk",21,"1");
	}
}

function onRaidoAnswerClick(){
	//摘机状态下，不能设置自动接听功能
	if(p_status != 0){
		return;
	}
	
	
	var rd_answer = document.getElementById("rd_answer");
	
	
	var sopen = rd_answer.value;
	
	if(sopen == "1"){
		
		
		sentNCommand("HP_SetAutoAnswer",13,"0");
	}else{
	
		
		sentNCommand("HP_SetAutoAnswer",13,"1");
	}
	
}

function onRaidoMuteClick(){
	var rd_mute = document.getElementById("rd_mute");
	if(p_status == 0){
		rd_mute.checked = false;
		return;
	}
	
	
	
	var sopen = rd_mute.value;
	
	if(sopen == "1"){
	
		
		sentNCommand("HP_Mute",20,"0");
	}else{
	
		
		sentNCommand("HP_Mute",20,"1");
	}
	
}

function onRaidopchsClick(){
	
	
	
	if(p_status != 0)
		return;
	
	
	
	var rd_pchs = document.getElementById("rd_pchs");
	
	
	var sopen = rd_pchs.value;

	if(sopen == "1"){
		
		
		sentNCommand("HP_SetPCEarSpk",21,"0");
	}else{
		
		
		sentNCommand("HP_SetPCEarSpk",21,"1");
	}
}

function onRaidomobilehsClick(){
	
	
	var rd_mobilehs = document.getElementById("rd_mobilehs");
	
	
	var sopen = rd_mobilehs.value;
	
	if(sopen == "1"){
		
		
		sentNCommand("HP_SetPCEarEar",22,"0");
	}else{
		
		
		sentNCommand("HP_SetPCEarEar",22,"1");
	}
}


function onNumClick(o){
	
	var id = o.id;

	switch(id){
		case "num_0":
			
			addInp_phonecode("0");
			DialOnLine("0");
		break;
		case "num_1":
		

			addInp_phonecode("1");
			DialOnLine("1");
			
		break;
		case "num_2":
			addInp_phonecode("2");
			DialOnLine("2");
		break;
		case "num_3":
			addInp_phonecode("3");
			DialOnLine("3");
		break;
		case "num_4":
			addInp_phonecode("4");
			DialOnLine("4");
		break;
		case "num_5":
			addInp_phonecode("5");
			DialOnLine("5");
		break;
		case "num_6":
			addInp_phonecode("6");
			DialOnLine("6");
		break;
		case "num_7":
			addInp_phonecode("7");
			DialOnLine("7");
		break;
		case "num_8":
			addInp_phonecode("8");


			DialOnLine("8");
		break;
		case "num_9":
			addInp_phonecode("9");
			DialOnLine("9");
		break;
		case "num_x":
			addInp_phonecode("*");
			DialOnLine("*");
		break;
		case "num_j":
			addInp_phonecode("#");
			DialOnLine("#");
		break;
	}
}

function pushPCS(){
	
	spush = [];
	phoneCodeShow = "";
	inp_phonecode = document.getElementById("inp_phonecode");
	inp_phonecode.value = phoneCodeShow;
}

function addInp_phonecode(num){
	phoneCodeShow = spush.join("");
	
	spush.push(num);
	phoneCodeShow = spush.join("");
	
	inp_phonecode = document.getElementById("inp_phonecode");
	inp_phonecode.value = phoneCodeShow;
	
}



function preDial(){
	inp_phonecode = document.getElementById("inp_phonecode");
				phoneCode = inp_phonecode.value;
				
	sentNCommand("HP_StartDial",5,phoneCode);
	has_dial = true;
}

function onDialClick(){
	
	     
	
	     
		 clearTimeout(dlyDlokTimeout);
		 switch(p_status){
		  case 0:
				inp_phonecode = document.getElementById("inp_phonecode");
				phoneCode = inp_phonecode.value;
	
				if(phoneCode == null || phoneCode == ""){
					
					sentNCommand("HP_OffHookCtrl",3,null);
				}else{
				   // if(icm_flag == 0){
						sentNCommand("HP_OffHookCtrl",3,null);
						setTimeout("preDial()","100"); 
						//sentNCommand("HP_StartDial",5,phoneCode);
						PreDialing = true;
					//}else{
						
					//}
					
				}
				clearTimeoutF();
			break;
			case 1:
			case 2:
			case 3:
				if(p_status == 2){
					window.alert("请先解除保留，才能挂机。");
					return;
				}
				sentNCommand("HP_HangUpCtrl",4,null);//有待商榷"para":{}没有赋值的JSON。
				PreDialing = false;
			break;
	  }
	
}

function onDialRecordClick(){
	
	
	
}



function onHangupClick(){
	

	
	sentNCommand("HP_HangUpCtrl",4,null);//有待商榷"para":{}没有赋值的JSON。
	PreDialing = false;

	
}


var isDialOnline = false;//是否为在线播号
function DialOnLine(num){
	if(p_status > 0){
		//{"req":"HP_SendDTMF","rid":7,"para":{"Para":"1"}} 
		isDialOnline = true;
		sentNCommand("HP_SendDTMF",7,num);//有待商榷"para":{}没有赋值的JSON。
	}
}

function onRecordClick(){
	
	var isLaw = judgeNetLaw();
	if(isLaw == false)
	 return;
	
	if(p_status > 0){
		
		switch(r_status){
		case 0:
			var path = document.getElementById("inp_recordaddr").value;
			
			if(path == null || path ==""){
				
				return;
			}
		//	if(icm_flag == 0){
				sentPCommand_R("HP_StartRecordFile",16,1,path);
		//	}else{
				//sentNCommand("HP_SetRecord",24,"1");
			//}
			break;
		case 1:
		
				stopRecorder();
			
			break;
		
		}
		
		
		
	}else{
		//本地录音
		
		var path = document.getElementById("inp_recordaddr").value;
		
		if(!r_status){
		
	        sentPCommand_R("HP_StartRecordFile",16,0,path);
  
		}else{
			
			stopRecorder();
		
		}
	}
}

function onFlashClick(){
	
	if(p_status > 0){
		
		var indexflash = 0;
		
		inp_flash = document.getElementById("inp_flash");
		
		var flashtime = inp_flash.value;
		
		switch(flashtime){
			case "100":
				indexflash = "0";
			break;
			case "180":
				indexflash = "1";
			break;
			case "300":
				indexflash = "2";
			break;
			case "600":
				indexflash = "3";
			break;
			case "1000":
				indexflash = "4";
			break;
		}
		
		sentNCommand("HP_Flash",11,indexflash);
			
	}
}



function incomDlg(show){
	
	if(show){
		
		div_icm = document.getElementById("div_icm");
		div_icm.style.display="block";
	}else{
		
		div_icm = document.getElementById("div_icm");
		div_icm.style.display="none";
	}
	
}

function dialDlg(show){
	if(show){
		div_dlg = document.getElementById("div_dlg");
		div_dlg.style.display="block";
	}else{
		div_dlg = document.getElementById("div_dlg");
		div_dlg.style.display="none";
	}
}

function showDialDlg(){
	dialDlg(true);
	incomDlg(false);
}


function showincomDlg(){
	
	incomDlg(true);

	dialDlg(false);
	if(a_status == 0){
		
		tip_a = document.getElementById("tip_a");
		tip_a.style.display="none";
	}else{
		
		tip_a = document.getElementById("tip_a");
		tip_a.style.display="block";
	}
}

function incomTimeoutF(){
	phoneCode = "";	
	phoneCodeShow = "";
	showDialDlg();
	
}


function dloffHookDelay(){
	
	sentNCommand("HP_OffHookCtrl",3,null);
}

var incomTimeout = null;

function clearTimeoutF(){
	
	if(incomTimeout != null){
		clearTimeout(incomTimeout);
	}
	
}
var SetLeaveRecordFlag = 0;
function onAcpClick(){
	
	
	clearTimeoutF();
	clearTimeout(dlyDlokTimeout);
	if(r_status == 1){
		
		stopRecorder();
	}
	
	if(a_status > 0 ){
		SetLeaveRecordFlag = 0;
		sentNCommand("HP_SetLeaveRecord",10,"0");
		
	}
	mAudio = document.getElementById("audio1");
	if(mAudio.played){
		
		mAudio.pause();
	}

	
	ringCount = 0;
	
	if(icm_flag == 0){
		sentNCommand("HP_OffHookCtrl",3,null);
	}else{
		if(a_status == 0){/*没有进入答录*/
			sentNCommand("HP_OffHookCtrl",3,null);
		}else{
			inp_phonecode = document.getElementById("inp_phonecode");
					inp_phonecode.value = phoneCodeShow;
					showDialDlg();
					
					clearTimeoutA();
					setP_status(1);
			        showUIDialStatus(p_status);
					return;
		}
	}
	
	
	
	showDialDlg();

	inp_phonecode = document.getElementById("inp_phonecode");
	inp_phonecode.value = phoneCodeShow;
	
	
}

function deASCII(num){
	switch(num){
		case 48:
			return "0";
		
		case 49:
			return "1";
		case 50:
			return "2";
		case 51:
			return "3";
		case 52:
			return "4";
		case 53:
			return "5";
		case 54:
			return "6";
		case 55:
			return "7";
		case 56:
			return "8";
		case 57:
			return "9";
		case 35:
			return "#";
		case 42:
			return "*";
	}
}


	
	function onHoldClick(){
		
		switch(p_status){
			case 1:
			case 3:
				sentNCommand("HP_Hold",19,"1");
			break;
			case 2:
				sentNCommand("HP_Hold",19,"0");
			break;
		}
	}
	
	function onUnHoldClick(){
		
		sentNCommand("HP_Hold",19,"0");
	}
	
	//20220217  xl修改新增测试
	function onInitClick(){
		
		sentNCommand("HP_Init",1,"0");
	}
	
	
	function onRefuseDly(){
		sentNCommand("HP_HangUpCtrl",4,null);
	}
	
	function onRefuseClick(){
		
	clearTimeout(dlyDlokTimeout);
	if(a_status == 0){
		
		if(icm_flag == 0){
		sentNCommand("HP_OffHookCtrl",3,null);
		setTimeout("onRefuseDly()","1200"); 
		//sentNCommand("HP_HangUpCtrl",4,null);
		}else{
			sentNCommand("HP_CallReject",26,null);
		}
		}else{
			clearTimeoutF();
			if(a_status == 1 ){
		//{"req":"HP_ playOGM","rid":29,"para":{"Para":"0"}}
		        SetLeaveRecordFlag = 0;
				sentNCommand("HP_SetLeaveRecord",10,"0");
		
			}
	
			if(mAudio.played){
		
				mAudio.pause();
			}

			if(r_status == 1){
				
				stopRecorder();
			}
			sentNCommand("HP_HangUpCtrl",4,null);
		}
	}
	//设置答录时间
	function setAnswerTime(at){
	}
	//设置多少铃声后播报
	function setAnswerRing(rc){
	}
	
	
	
	//答录提示音.(即告诉电话机播报哪个音乐文件)
	function AnswerBdTip(musicFP){
		
	}
	//开始答录
	function AnswerStart(){
	}
	
	//答录结束
	function AnswerEnd(){
	}
	

	//当断开时。
    function initPhoneNet(){
		//初始化网页
	}
	
	
	function utf16to8(str) {
    var out, i, len, c;
    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
        c = str.charCodeAt(i);
        if ((c >= 0x0001) && (c <= 0x007F)) {
            out += str.charAt(i);
        } else if (c > 0x07FF) {
            out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
            out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
            out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
        } else {
            out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
            out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
        }
    }
    return out;
}

function utf8to16(str) {
    var out, i, len, c;
    var char2, char3;
    out = "";
    len = str.length;
    i = 0;
    while(i < len) {
        c = str.charCodeAt(i++);
        switch(c >> 4)
        {
          case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
            // 0xxxxxxx
            out += str.charAt(i-1);
            break;
          case 12: case 13:
            // 110x xxxx   10xx xxxx
            char2 = str.charCodeAt(i++);
            out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
            break;
          case 14:
            // 1110 xxxx  10xx xxxx  10xx xxxx
            char2 = str.charCodeAt(i++);
            char3 = str.charCodeAt(i++);
            out += String.fromCharCode(((c & 0x0F) << 12) |
                           ((char2 & 0x3F) << 6) |
                           ((char3 & 0x3F) << 0));
            break;
        }
    }
    return out;
}

function onRaidoDLClick(){
	
	rd_dl = document.getElementById("rd_dl");
	var value = rd_dl.value;

	if(value == "1"){
		
		rd_dl.checked = false;
		
		rd_dl.value = "0";
		
		
	}else{
	
		
		rd_dl.value = "1";
		
	}
}

function answer_end(){
	
	
	stopRecorder();
	sentNCommand("HP_HangUpCtrl",4,null);
	
	
	
}

function clearTimeoutA(){
	
	if(incomTimeout != null){
		
	}
	
}


function include(path){ 
    var a=document.createElement("script");
    a.type = "text/javascript"; 
    a.src=path; 
    var head=document.getElementsByTagName("head")[0];
    head.appendChild(a);
 }
 
function onRaidoheClick(){
	
	sentNCommand("HP_EaroffHook",28,null);
	
	setTimeout("preDial()","100"); 
						//sentNCommand("HP_StartDial",5,phoneCode);
						PreDialing = true;

}

function showUIDialStatus(status_tmep){
	 switch(status_tmep){
		 case 0:
		 	
		 	btn_dial = document.getElementById("btn_dial");
			btn_dial.className = "btn btn-info btn-block";
		 	btn_dial.innerHTML = "摘机";
			btn_hold = document.getElementById("btn_hold");
			btn_hold.className = "btn btn-info btn-block";
			btn_hold.innerHTML = "保留";
			rd_he = document.getElementById("rd_he");
		    rd_he.value = "0";
			rd_he.checked = false;
		 break;
		 case 1:
			
			btn_dial = document.getElementById("btn_dial");
			btn_dial.className = "btn btn-danger btn-block";
			btn_dial.innerHTML = "挂机";
			btn_hold = document.getElementById("btn_hold");
			btn_hold.className = "btn btn-info btn-block";
			btn_hold.innerHTML = "保留";
		 break;
		 case 2:
		   
			btn_dial = document.getElementById("btn_dial");
			btn_dial.className = "btn btn-danger btn-block";
			btn_dial.innerHTML = "挂机";
			
			btn_hold = document.getElementById("btn_hold");
			btn_hold.className = "btn btn-danger btn-block";
			btn_hold.innerHTML = "解除保留";
			
		 break;
		 case 3:
		   rd_he = document.getElementById("rd_he");
		   rd_he.value = "1";
		   rd_he.checked = true;
		 break;
	}
}
var pre_p_status = 0;//记录前一个状态
function setP_status(status_temp){
	pre_p_status = p_status;
	p_status = status_temp;
}
//查询话机的状态
function checkPstatus(){
	//{"req":"HP_QueryPhoneStatus","rid":8,"para":{}} 
	sentNCommand("HP_QueryPhoneStatus",8,null);
}

function playAnswerTip(){
	mAudio.currentTime = 0;//重新播放
	mAudio.play();
}

function onRaidoDVoiceClick(){
	//if(dv_status == 0)
	var rd_dvoice = document.getElementById("rd_dvoice");
	
	var sopen = rd_dvoice.value;
	
	if(sopen == "1"){
	
		
		sentNCommand("HP_SetDialTone",12,"0");
	}else{
	
		
		sentNCommand("HP_SetDialTone",12,"1");
	}
}

function onRaidoICMClick(){
	var rd_icm = document.getElementById("rd_icm");
	
	var sopen = rd_icm.value;
	
	if(sopen == "1"){
	
		
		sentNCommand("HP_SetIcm",23,"0");
	}else{
	
		
		sentNCommand("HP_SetIcm",23,"1");
	}
}

function onRelayClick(){
	if(p_status > 0){
		
		var indexflash = 0;
		
		inp_inp = document.getElementById("inp_relay");
		
		var flashtime = inp_flash.value;
		
		switch(flashtime){
			case "100":
				indexflash = "0";
			break;
			case "180":
				indexflash = "1";
			break;
			case "300":
				indexflash = "2";
			break;
			case "600":
				indexflash = "3";
			break;
			case "1000":
				indexflash = "4";
			break;
		}
		
		sentNCommand("ZhuanBo",18,indexflash);
			
	}
}

function onRaidoDelMsgClick(){
	
	
	sentNCommand("HP_DelNewSms",27,"0");
	
	
}

function onSendMsgClick(){
	inp_pmsg = document.getElementById("inp_pmsg");
	var inp_phonecode = document.getElementById("inp_phonecode");
	sentPCommand_M("HP_SendSmsText",25,inp_pmsg.value,inp_phonecode.value);
}

 function onDeleteUploadClick(){
	
	var del_path = document.getElementById("inp_recordaddr").value;
			
	if(del_path == null || del_path ==""){
				return;
	}
	
	sentNCommand("HP_DelRecordFile",31,del_path);
	
	//var strcommand = commandNormal("HP_DelRecordFile",31,del_path);
	
	//wsClient.send(strcommand);
}


function reInit(){
  
	phoneCode = "";
	phoneCodeShow = "";
	spush = [];
	p_status = 0;//摘挂机状态0:为挂机;1：为摘机;2:为HOLD;3：为耳机摘机
	r_status = 0;//录音机状态： 0：停止录音 1:正在录音
	a_status = 0;//答录的状态： 0：停止答录 1：准备答录 2:正在答录
	dv_status = 0;//播号音开关: 0: 播号音关闭 1：播号音打开
	
	icm_flag = 0;//ICM通道关：0；ICM通道开： 1
	pre_command ="";
	/////////////////////////////////
	 document.getElementById("serialno").innerHTML = "设备串号:";
	 var cnnstate = document.getElementById("cnnstate").innerHTML = "设备未连接";
	 var cnnstate = document.getElementById("messagenum").innerHTML = "接收到知信内容:";
	 pre_amsg ="";
	 
	 var rd_ring = document.getElementById("rd_ring");
	 rd_ring.value = 1;
	 rd_ring.checked = true;
	 
	 var rd_voice = document.getElementById("rd_voice");
	 rd_voice.value = 0;
	 rd_voice.checked = false;
	 
	 var rd_answer = document.getElementById("rd_answer");
	 rd_answer.value = 0;
	 rd_answer.checked = false;
	 
	  var rd_mute = document.getElementById("rd_mute");
	 rd_mute.value = 0;
	 rd_mute.checked = false;
	 
	  var rd_dl = document.getElementById("rd_dl");
	 rd_dl.value = 0;
	 rd_dl.checked = false;
	 
	  var rd_he = document.getElementById("rd_he");
	 rd_he.value = 0;
	 rd_he.checked = false;
	 
	  var rd_dvoice = document.getElementById("rd_dvoice");
	 rd_dvoice.value = 0;
	 rd_dvoice.checked = false;
	 
	  var rd_mobilehs = document.getElementById("rd_mobilehs");
	 rd_mobilehs.value = 0;
	 rd_mobilehs.checked = false;
	 
	  var rd_icm = document.getElementById("rd_icm");
	 rd_icm.value = 0;
	 rd_icm.checked = false;
	 
	  var rd_delmsg = document.getElementById("rd_delmsg");
	 rd_delmsg.value = 0;
	 rd_delmsg.checked = false;
	 
	////////////////////////////////////
	 btn_record = document.getElementById("record");
	 btn_record.className = "btn btn-default";
	 
	  inp_phonecode = document.getElementById("inp_phonecode");
	  inp_phonecode.value = phoneCodeShow;
	  
	  btn_dial = document.getElementById("btn_dial");
	  btn_dial.className = "btn btn-info btn-block";
	  btn_dial.innerHTML = "摘机";
	  btn_hold = document.getElementById("btn_hold");
	  btn_hold.className = "btn btn-info btn-block";
	  btn_hold.innerHTML = "保留";
	  
	  showDialDlg();
}

function onRaidoRUploadClick(){
	
	rupload = document.getElementById("rupload");
	var value = rupload.value;

	if(value == "1"){
		
		rupload.checked = false;
		rupload.value = "0";
		
		
	}else{
	
		
		rupload.value = "1";
		rupload.checked = true;
	
	}
}

function onRaidoRUpremoteClick(){
	
	var rupremote = document.getElementById("rupremote");
	var value = rupremote.value;

	if(value == "1"){
		
		rupremote.checked = false;
		rupremote.value = "0";
		
		
	}else{
	
		
		rupremote.value = "1";
		rupremote.checked = true;
	
	}
}



function stopRecorder(){
	
	if(r_status == 0){
		return;
	}
	rupload = document.getElementById("rupload");
	var value = rupload.value;
	
	if(value == "1"){
		
		var user = document.getElementById("inp_uploaduser").value;
		
		
		var pw  = document.getElementById("inp_uploadpw").value;
		
		var netaddr = document.getElementById("inp_recorduploadaddr").value;
		if(netaddr == "" || netaddr == null){
			window.alert("录音上传到网络，网络地址不能为空");
			return;
		}
		
		HasSendStopR = true;
		sendStopRecorder(user,pw,netaddr);
	
	}else{
	    HasSendStopR = true;
		sendStopRecorder("","","");
	
	}
	
	

	
	
}


function upLoadRemoteR(){
	var rupremote = document.getElementById("rupremote");
	var value = rupremote.value;
	
	if(value == "1"){
		
		
		remoteaddr = document.getElementById("inp_recordremoteaddr").value;
		if(remoteaddr == "" || remoteaddr == null){
			window.alert("录音上传到云，云地址不能为空");
			return;
		}
		setTimeout("delaySendUpRemote()","2000"); 
		
		//sendUpRemote(remoteaddr);
	
	}
}



function delaySendUpRemote(){
	sendUpRemote(remoteaddr);
}


function judgeNetLaw(){
	rupload = document.getElementById("rupload");
	var value = rupload.value;
	
	if(value == "1"){
		
		var user = document.getElementById("inp_uploaduser").value;
		
		
		var pw  = document.getElementById("inp_uploadpw").value;
		
		var netaddr = document.getElementById("inp_recorduploadaddr").value;
		if(netaddr == "" || netaddr == null){
			window.alert("录音上传到网络，网络地址不能为空");
			return false ;
		}
	}
		
		return true;
	
}

function add_phonecode(num){
	
	spush.push(num);
	phoneCodeShow = spush.join("");
	
	//inp_phonecode = document.getElementById("inp_phonecode");
	//inp_phonecode.value = phoneCodeShow;
	
}

function pKeyEvent(k){
	
	switch(k){
		case 0:
		
			add_phonecode("0");
			DialOnLine("0");
		break;
		case 1:
		
			add_phonecode("1");
			DialOnLine("1");
			
		break;
		case 2:
			add_phonecode("2");
			DialOnLine("2");
		break;
		case 3:
			add_phonecode("3");
			DialOnLine("3");
		break;
		case 4:
			add_phonecode("4");
			DialOnLine("4");
		break;
		case 5:
			add_phonecode("5");
			DialOnLine("5");
		break;
		case 6:
			add_phonecode("6");
			DialOnLine("6");
		break;
		case 7:
			add_phonecode("7");
			DialOnLine("7");
		break;
		case 8:
			add_phonecode("8");


			DialOnLine("8");
		break;
		case 9:
			add_phonecode("9");
			DialOnLine("9");
		break;
		case 42:
			add_phonecode("*");
			DialOnLine("*");
		break;
		case 35:
			add_phonecode("#");
			DialOnLine("#");
		break;
	}
}





function xKeyEvent(e){   //通用的兼容各个浏览器的响应键盘事件函数


var e = e || window.event;  //事件处理



switch(e.keyCode | e.which | e.charCode)  //按键 ASCII 码值
    {
     case 8: //响应退格键
          {
          //...x operation...	
		  window.alert("退格键");
          break;
          }
 
     case 9: //响应Tab键
          {
          //...x operation...		 
          break;
          }
 
     case 16: //响应Shift键
          {
          //...x operation...		
          break;
          }
 
     case 17: //响应Ctrl键
          {
          //...x operation...		
          break;
          }
 
     case 18: //响应Alt键
          {
          //...x operation...		 
          break;
          }
 
     case 20: //响应Caps Lock键
          {
          //...x operation...		
          break;
          }
 
     case 27: //响应Esc键
          {
          //...x operation...		  
          break;
          }
 
     case 32: //响应空格键
          {
          //...x operation...		 
          break;
          }
 
     case 33: //响应PageUp键
          {
          //...x operation...		 
          break;
          }
 
     case 34: //响应PageDown键
          {
          //...x operation...		  
          break;
          }
 
   /*  case 35: //响应End键
          {
          //...x operation...		 
          break;
          }*/
 
     case 36: //响应Home键
          {
          //...x operation...		 
          break;
          }
		  
     case 37: //向左方向键
          {
          //...x operation...		
          break;
          }
 
     case 38: //向上方向键
          {
          //...x operation...		 
          break;
          }
 
     case 39: //向右方向键
          {
          //...x operation...		 
          break;
          }
 
     case 40: //向下方向键
          {
          //...x operation...		 
          break;
          }
 
     case 45: //响应Insert键
          {
          //...x operation...		  
          break;
          }
 
     case 46: //响应Delete键
          {
          //...x operation...		  
          break;
          }
	 case 35://“#”号键
	 case 42://“*”号键
		  
     case 48: //响应 0 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...	
		 // window.alert("接收到键盘事件！");
         // break;
         // }
		  
     case 49: //响应 1 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		 
        //  break;
        //  }
		  
     case 50: //响应 2 键, // 0 --9 对应的ASCII码值 48 -- 57
        //  {
          //...x operation...		
        //  break;
        //  }
		  
     case 51: //响应 3 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		 
        //  break;
        //  }
		  
     case 52: //响应 4 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		  
         // break;
        //  }
		  
     case 53: //响应 5 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		  
         // break;
         // }
		  
     case 54: //响应 6 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		  
         // break;
         // }
 
     case 55: //响应 7 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		  
         // break;
         // }
		  
     case 56: //响应 8 键, // 0 --9 对应的ASCII码值 48 -- 57
         // {
          //...x operation...		 
         // break;
        //  }
		  
     case 57: //响应 9 键, // 0 --9 对应的ASCII码值 48 -- 57
          {
          //...x operation...
		
		  	var temp_num = e.keyCode | e.which | e.charCode;
	      	
			if(temp_num == 42 || temp_num == 35){
		  		pKeyEvent(temp_num);
		  	}else{
				pKeyEvent(temp_num - 48);
		  	}
          	
			break;
           }
 
     case 65: //响应 a 键, //a -- z, 对应的ASCII码值 65 -- 90
          {
          //...x operation...		
          break;
          }
		  
     case 90: //响应 z 键, //a -- z, 对应的ASCII码值 65 -- 90
          {
          //...x operation...
		 
          break;
          }
 
     case 91: //响应左WIN键
          {
          //...x operation...		  
          break;
          }
 
     case 92: //响应右WIN键
          {
          //...x operation...		 
          break;
          }
		  
     case 96: //小键盘区0	//小键盘区0--9对应键值 96--105
          {
          //...x operation...		
          break;
          }
		  
     case 105: //小键盘区9	//小键盘区0--9对应键值 96--105
          {
          //...x operation...		
          break;
          }
 
     case 112: //响应F1键 //码112--123对应F1--F12
          {
          //...x operation...		  
          break;
          }
		  
     case 113: //响应F2键 // 码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
		  
     case 114: //响应F3键 // 码112--123对应F1--F12
          {
          //...x operation...		  
          break;
          }
		  
     case 115: //响应F4键 //码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
		  
     case 116: //响应F5键 //码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
		  
     case 117: //响应F6键 // 码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
 
     case 118: //响应F7键 // 码112--123对应F1--F12
          {
          //...x operation...		
          break;
          }
		  
     case 119: //响应F8键 //码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
		  
     case 120: //响应F9键 //码112--123对应F1--F12
          {
          //...x operation...		
          break;
          }
		  
     case 121: //响应F10键 //码112--123对应F1--F12
          {
          //...x operation...		
          break;
          }
		  
     case 122: //响应F11键 //码112--123对应F1--F12
          {
          //...x operation...		 
          break;
          }
		  
     case 123: //响应F12键 //码112--123对应F1--F12
          {
          //...x operation...		
          break;
          }
 
     case 144: //响应 NumLock 键 
          {
          //...x operation...		 
          break;
          }
 
     case 145: //响应 ScrollLock 键 
          {
          //...x operation...		
          break;
          }
 
     case 186: //响应 ScrollLock 键 
          {
          //...x operation...		
          break;
          }
		  
     case 187: //响应 等号 键 
          {
          //...x operation...		
          break;
          }
 
     case 188: //响应 逗号 键 
          {
          //...x operation...		
          break;
          }
 
     case 189: //响应 减号 键 
          {
          //...x operation...		
          break;
          }
		  
     case 190: //响应 点号 键 
          {
          //...x operation...		
          break;
          }
		  
     case 191: //响应 正斜杠 键 
          {
          //...x operation...		  
          break;
          }
 
     case 192: //响应 (前导点号)` 键 
          {
          //...x operation...		
          break;
          }
 
     case 219: //响应 [ 键 
          {
          //...x operation...		
          break;
          }
		  
     case 220: //响应 \ 键 
          {
          //...x operation...		
          break;
          }
 
     case 221: //响应 ] 键 
          {
          //...x operation...		
          break;
          }
 
     case 13: //响应回车键
          {
          //...x operation...		
          break;
          }
     default:
	  //...default operation...	
    }
}

function onInp_phonecodeKeyDown(){
	
	var key = event.keyCode || event.charCode;
	
	if(key == 8 || key == 46){
		
	
		if(p_status == 0 && phoneCodeShow != ""){
		
			spush.pop();
		
			phoneCodeShow = spush.join("");
	      
		
		}
	
	}
	
}

//17命令回复标识
var StopRTouchedBy17 = false;

//处理发了开始录音，但没有发停止录音时，服务自动停止录音的事件后续处理。
function NotSendStopREvent(){
	
	if(HasSendStopR == false){
		
	   HasSendStopR = true;
	   //上传云录音
	   upLoadRemoteR();
		
	   rupload = document.getElementById("rupload");
	   var value = rupload.value;
	   if(value == "1"){
		
		  var user = document.getElementById("inp_uploaduser").value;
		
		
		  var pw  = document.getElementById("inp_uploadpw").value;
		
		  var netaddr = document.getElementById("inp_recorduploadaddr").value;
		  if(netaddr == "" || netaddr == null){
				window.alert("录音上传到网络，网络地址不能为空");
				return;
		  }
		
		        StopRTouchedBy17 = true;
				sendStopRecorder(user,pw,netaddr);
	
	 }
			
			
  }else{
			//上传云录音
			
		if(StopRTouchedBy17 != true){
			upLoadRemoteR();
		}
		
		StopRTouchedBy17 = false;
  }
		
	
}
//17事件使能标识

function Enable17Event(){
	//Enable_17 = true;
	
}

function onReStartPluginsClick(){
	sentNCommand("HP_ReStartPlugIn",34,null);
}


function onQueryPlugineStatusClick(){
	sentNCommand("HP_QueryPhoneOnlineStatus",35,"0");
}

//setTimeout("Enable17Event()","1000");

/*
D:\USBPhone
*/	


