<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>

<h1>My first PHP page</h1>



<?php

$txt1="Hello world!";
$txt2="what a nice day!";
echo $txt1 . " " . $txt2;

echo "<br>";

echo strlen("Hello world!");

echo "<br>";

echo strpos("Eello world!","world");

?>


<br />




</body>
</html>
